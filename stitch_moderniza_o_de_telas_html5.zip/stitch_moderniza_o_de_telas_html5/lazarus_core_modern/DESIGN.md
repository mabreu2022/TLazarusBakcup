---
name: Lazarus Core Modern
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c3c6d7'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#8d90a0'
  outline-variant: '#434655'
  surface-tint: '#b4c5ff'
  primary: '#b4c5ff'
  on-primary: '#002a78'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#0053db'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffb596'
  on-tertiary: '#581e00'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  headline-lg:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin: 20px
---

## Brand & Style

The design system is engineered for efficiency, reliability, and technical precision. It caters to developers and power users who require a high-density, low-friction interface for managing portable environments. 

The aesthetic is **Modern Utilitarian**, blending elements of **Corporate Modern** with a **Developer-Centric** focus. It emphasizes content over decoration, utilizing a dark-first approach to reduce eye strain during long sessions. The visual mood is serious, stable, and high-performance, evoking the feeling of a sophisticated terminal or workstation.

Key principles:
- **Efficiency over Embellishment:** Every pixel serves a functional purpose.
- **Data Integrity:** High contrast and clear hierarchy for logs and status indicators.
- **Subtle Modernity:** Softened edges and micro-elevations to prevent the interface from feeling "dated" or purely skeletal.

## Colors

The palette is optimized for a deep-dark environment. The foundation is a "Midnight" scale rather than pure black, providing better depth and perception of layers.

- **Primary (Electric Blue):** Used for primary actions, active states, and focus indicators. It provides a technical, "connected" feel.
- **Secondary (Terminal Green):** Reserved for success states, active logs, and "Launch" actions, nodding to traditional IDE/Terminal environments.
- **Neutral/Backgrounds:** We use a tiered system of dark slate. The deepest color is for the app canvas, while slightly lighter tones define cards and toolbars.
- **Accents:** High-contrast white is used sparingly for primary text to ensure maximum legibility against the dark background.

## Typography

This design system uses a dual-font strategy to balance character and readability.

1. **Geist Sans:** The primary body face. It is exceptionally clean, with a technical geometric structure that fits the modern developer aesthetic.
2. **JetBrains Mono:** Used for headlines, labels, and all data/log content. This reinforces the "IDE/Manager" nature of the tool and ensures that alphanumeric strings (like file paths and IDs) are easily distinguishable.

**Log Legibility:** All log output must use `code-sm` or `label-md` to ensure character alignment and readability of timestamps and error codes.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid** model. The sidebar remains fixed for constant navigation access, while the main dashboard area uses a fluid 12-column grid to maximize the visibility of logs and status cards.

- **Density:** The system uses a high-density rhythm (base 4px) to allow more information to be visible at once without scrolling.
- **Safe Areas:** Standard containers should have 16px (md) padding. Data-heavy lists or logs can drop to 8px (sm) internal padding.
- **Breakpoints:**
  - **Desktop (default):** 12 columns, 16px gutters.
  - **Compact/Tablet:** 6 columns, 12px gutters.

## Elevation & Depth

In this design system, depth is communicated through **Tonal Layering** rather than heavy shadows. This maintains a clean, professional "flat-plus" look.

1. **Level 0 (Base):** `#020617` - The main application background.
2. **Level 1 (Cards/Sidebar):** `#0F172A` - Used for containers that sit on the base.
3. **Level 2 (Modals/Popovers):** `#1E293B` - Used for elevated interactive elements, accompanied by a subtle 1px border of `#334155`.
4. **Interactive Focus:** Elements that are focused or active should use a 1px primary-colored (`#2563EB`) outline instead of a shadow.

## Shapes

The shape language is **Soft-Technical**. We avoid perfectly sharp corners to prevent a dated look, but maintain small radii to preserve the "utilitarian" feel.

- **Standard Radius:** 4px (Soft) for buttons, input fields, and cards.
- **Inner Elements:** When an element is nested inside another (e.g., a progress bar inside a card), the inner radius should be 2px to maintain visual harmony.

## Components

### Buttons
- **Primary:** Background `#2563EB`, text `#F8FAFC`. Bold, all-caps or medium-weight JetBrains Mono.
- **Secondary/Ghost:** Border `#334155`, no background. Text `#94A3B8`.
- **Launch Action:** Background `#10B981`, text `#020617` (High contrast).

### Input Fields
- Dark backgrounds (`#020617`) with a subtle 1px border (`#334155`). 
- Active state: Border changes to primary color with no glow.

### Cards & Panels
- Background `#0F172A`. 
- Header areas should have a subtle bottom border (`1px solid #1E293B`) to separate titles from content.

### Logs & Terminal
- Background: Pure black (`#000000`).
- Text: White (`#F8FAFC`) for messages, Secondary (`#10B981`) for timestamps, and Amber (`#F59E0B`) for warnings.

### Progress Bars
- Track: `#1E293B`.
- Fill: Linear gradient from Primary to Secondary to indicate "activity" or "loading."