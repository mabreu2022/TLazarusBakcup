---
name: Lazarus Core Modern Light
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#434655'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#515f74'
  on-secondary: '#ffffff'
  secondary-container: '#d5e3fc'
  on-secondary-container: '#57657a'
  tertiary: '#4d556b'
  on-tertiary: '#ffffff'
  tertiary-container: '#656d84'
  on-tertiary-container: '#eef0ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#d5e3fc'
  secondary-fixed-dim: '#b9c7df'
  on-secondary-fixed: '#0d1c2e'
  on-secondary-fixed-variant: '#3a485b'
  tertiary-fixed: '#dae2fd'
  tertiary-fixed-dim: '#bec6e0'
  on-tertiary-fixed: '#131b2e'
  on-tertiary-fixed-variant: '#3f465c'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: JetBrains Mono
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: JetBrains Mono
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: JetBrains Mono
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: JetBrains Mono
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: 0.05em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.4'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  container-max: 1440px
---

## Brand & Style
The design system is a high-precision, technical interface designed for engineering and data-intensive environments. It transitions the original "Lazarus" aesthetic into a high-clarity light mode that emphasizes stability, transparency, and logical organization.

The style is **Corporate Modern with Technical Minimalism**. It utilizes a "White-Label Engineering" approach: heavy use of whitespace, crisp borders, and monospaced typography to evoke the feeling of a sophisticated IDE or a high-end laboratory instrument. The emotional response should be one of absolute reliability and cognitive ease.

## Colors
The palette is anchored by a pure white canvas (`#FFFFFF`) to maximize contrast and perceived cleanliness. Depth is achieved through a systematic "Cool Gray" scale that utilizes subtle blue tints to maintain the technical heritage of the brand.

- **Primary Blue (#2563EB):** Reserved for primary actions and active states. It has been verified for AA accessibility against white and light gray surfaces.
- **Surface Tiers:** Use `#F1F5F9` for secondary background areas (sidebars, headers) and `#E2E8F0` for inset elements or stroke-heavy containers.
- **Status Colors:** These have been darkened from the dark-mode originals to ensure high legibility and "seriousness" on light backgrounds. They avoid neon tones in favor of "Deep Earth" variants.

## Typography
This design system exclusively uses **JetBrains Mono** to maintain its technical identity. By utilizing a monospaced font for all UI elements, the interface gains a rhythmic, grid-like precision.

- **Contrast:** Main body text should use `#0F172A` (Slate 900) for maximum readability. Secondary text should use `#475569`.
- **Scaling:** Headlines are kept relatively compact to ensure high information density. 
- **Labels:** Always use Medium (500) weight and slight letter-spacing to distinguish metadata from body content.

## Layout & Spacing
The layout relies on a **12-column Fixed Grid** for desktop, centered within the viewport. The spacing philosophy is strictly "4px-base," meaning all margins, paddings, and height increments are multiples of 4.

- **Information Density:** High. Use `12px` or `16px` padding for internal container spacing to keep elements tight and professional.
- **Alignment:** All elements must align to the baseline of the typography to maintain the "Technical Stable" feel.
- **Mobile:** Transition to a fluid 4-column grid with `16px` gutters.

## Elevation & Depth
In this light mode system, depth is communicated through **Tonal Layering** and **Thin Outlines** rather than heavy shadows.

- **Level 0 (Canvas):** Pure White (#FFFFFF).
- **Level 1 (Sub-sections):** Soft Blue-Gray (#F8FAFC) with a 1px border of `#E2E8F0`.
- **Level 2 (Modals/Popovers):** White surface with a very subtle, highly diffused shadow (`0px 10px 15px -3px rgba(0, 0, 0, 0.05)`).
- **Interactive States:** Use a "Pressed" look for buttons by slightly darkening the background rather than adding inner shadows.

## Shapes
The shape language is "Soft-Technical." We use a **0.25rem (4px)** base radius for all standard components like buttons, inputs, and cards. This provides a hint of modernity without sacrificing the structured, "architectural" feel of the interface. 

- Use **0px** (Sharp) for vertical dividers and structural separators.
- Use **Full Rounding (Pill)** only for status badges and tags to distinguish them from interactive buttons.

## Components
- **Buttons:** Primary buttons use `#2563EB` with white text. Ghost buttons use `#475569` text with a 1px border that only appears on hover.
- **Inputs:** Use a white background with a `#CBD5E1` border. On focus, the border changes to the primary blue with a 2px outer ring of 10% opacity blue.
- **Chips/Tags:** Monospace font, uppercase, 12px. Backgrounds should be very light versions of the status colors (e.g., Success tag: `#DCFCE7` background, `#166534` text).
- **Cards:** No shadows by default. Use a 1px border of `#E2E8F0`. Header sections within cards should have a light gray background (`#F1F5F9`) to separate metadata from content.
- **Data Tables:** Use alternating row stripes (Zebra striping) with `#F8FAFC`. Headers should be bold, `#0F172A`, with a solid 2px border-bottom.
- **Monospace Monitors:** For technical readouts, use an inset box with a `#0F172A` background and `#38BDF8` (Light Blue) text to emulate a terminal within the light UI.